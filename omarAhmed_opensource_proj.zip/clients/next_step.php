 
 <fieldset  style="margin:0 10%;">
	 <center>
		<h2> خطة سير وتطوير المشروع  	وتحديد الاحتياجات </h2>
		<h2> Next step  -  Contact <a href="">Omar Ahmed </a>-  We need the following </h2>
	 </center>
		<ol>
			<li>
				<a href="#">Programmers</a> to complete the idea - (git)
			</li>
			
			<li>
				<a href="#">Front end developer</a> to enhance style
			</li>
			
			<li>
				<a href="#">Documentation</a> People who has the skills to document any update for the project
			</li>
			
			<li>
				<a href="#">Translators</a> to translate codes and and comments to Arabic language
			</li>
			
			<li>
				<a href="#">Security experts (CyberSecurity) </a> with programming experience to test and 
			</li>
			 
			<li>
				<a href="#">Projects </a> to be open source translated to Arabic language
			</li>
			 
			<li>
				<a href="#">May others </a> ideas
			</li>
			 
			<li>
				<a href="#">(Idea) Hosting, accessability & availability</a> to be available free only inside Yemen
			</li>
			
		</ol>
	  
 </fieldset>