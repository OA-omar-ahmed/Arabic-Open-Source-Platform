

<table border="0" id="ourteam" align="center" width="100%"  height="">
									
								<table  width="100%"  height="" >
									<td  width="100%"  height="80%"  style="background:white; color:#333;overflow:auto; max-width:600px; ">
													
													
				
							<!-- Thumbnails  --> 			
												<table border="0" align="center" width="90%"  height="100%">
													<tr  >
													<td colspan="3" >
												 <center><p style="color:#ccc;">Our Community </p></center>
													</td>
													</tr>
													<tr  >
														<td  width="20%"  height="80%" style=" text-align:center; ">
 
															<br>Akrm Othman </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Community member </h4>
															<p> Analysis </p>
															 <p> <a href="#">Contact Me</a> </p>
														</td>
 														<td  width="20%"  height="80%" style=" text-align:center; ">
 
															<br>Your name </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Community member </h4>
															<p> Your share & work in this project</p> 
															<p> <a href="#">Contact Me</a> </p>
														</td>
 														 <td  width="20%"  height="80%" style=" text-align:center; ">
 
															<br>Another name </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Community member </h4>
															<p> Your share & work in this project</p> 
															<p> <a href="#">Contact Me</a> </p>
														</td>
 														 <td  width="20%"  height="80%" style=" text-align:center; ">
 
															<br> Another name </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Community member </h4>
															<p> Your share & work in this project</p> 
															<p> <a href="#">Contact Me</a> </p>
														</td>
 														 
													</tr>
												</table>
													
									</td>
								</tr>
							</table>

