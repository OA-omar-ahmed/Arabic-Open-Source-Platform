 &nbsp; &nbsp; &nbsp; |&nbsp; &nbsp; &nbsp;  
 <a  href="home.php" title="Login"> الرئيسية </a> 
 &nbsp; &nbsp; &nbsp; |&nbsp; &nbsp; &nbsp;  
 <a   href="login.php" title="Login"> تسجيل دخول </a>
 &nbsp; &nbsp; &nbsp; |&nbsp; &nbsp; &nbsp;  
 <a target="oii_llaaa" href="user_setting.php?Ad=true" title="Create new user">انشاء حساب جديد </a>
<iframe id="oii_llaa" name="oii_llaaa" src="user_setting.php?Ad=true" frameborder="0" marginwidth="0" marginheight="0" scrolling="yes" style=" width:100%; height:100%;" ></iframe>

