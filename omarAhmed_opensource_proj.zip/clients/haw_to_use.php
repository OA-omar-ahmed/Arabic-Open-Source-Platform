	<center> 
		<h2>مشاريع و مصادر برمجية مفتوحة المصدر</h2>
		<h2>كيفية نشر مشروعك</h2>
	</center>
		

<fieldset>
  <center>
    <small>
      Open Source Libraries
      <br>
      a massive collection of the world's best open source software
    </small>
    <br>
    <br>
    <div style="border:1px solid #ccc; padding:10px; float:left; margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=Open Source Programming Projects">مشاريع و مصادر برمجية مفتوحة المصدر - <br> Open Source Programming Projects</a>
    </div>
    <div style="border:1px solid #ccc; padding:10px;float:left; margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=Arabic Programming Language Recources">مصادر للغه برمجية عربية <br> Arabic Programming Language Recources</a>
    </div>
    <div style="border:1px solid #ccc; padding:10px; float:left;margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=Lessons">شروحات<br>Lessons </a>
    </div>
    <div style="border:1px solid #ccc; padding:10px; float:left; margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=Others">مصادر تعليمية اخرى<br>Other recources </a>
    </div>
    <div style="border:1px solid #ccc; padding:10px; float:left; margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=Arabic">Arabic </a> Programming language and recourses.
    </div>
    <div style="border:1px solid #ccc; padding:10px; float:left; margin:10px; width:30%; min-width:200px; height:200px; ">
      <a href="projects_list.php?Co=1&proj_class=saas">Cloud - SaaS </a>
    </div>
  </center>
</fieldset>
		
	
		
 