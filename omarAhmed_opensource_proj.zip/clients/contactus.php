<table border="0" id="ourteam" align="center" width="100%"  height="100%">
									
								<table  width="100%"  height="100%" >
									<td  width="100%"  height="80%"  style="background:white; color:#333;overflow:auto; max-width:600px; ">
							<!-- Thumbnails  --> 			
												<table border="0" align="center" width="90%"  height="100%">
													<tr  >
													<td colspan="3" >
												 <center><p style="color:#ccc;">Our Team & Our Community </p></center>
													</td>
													</tr>
													<tr  >
														<td  width="30%"  height="80%" style=" text-align:center; ">
															<h2 style=" "><a href="../assets/images/team/omar_ahmed2.png">
															<img class="user_comment_img" src="../assets/images/team/omar_ahmed.png" style="width:150px; height:150px;" />
															<br>Omar Ahmed Ali Al-Motwakel </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Team Leader &  Project Owner</h4>
															<p> Project idea  and  System analysis </p>
															<p> Developed  backend & front end </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">Contact Me</a> Or <a href="user_setting.php?Co&view_id=1">المشاريع</a>    </p>
														</td>
														<td  width="20%"  height="80%" style=" text-align:center; ">
															<h2 style=" "><a href="add_page.php">
															<img class="user_comment_img" src="../assets/images/team/flower_img2.png" style="width:150px; height:150px;" />
															
															<br>Doa'a Asaf </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Member </h4>
															<p> Design UX / UI</p>
															<p> Documentation  </p>
															<p> <a href="fb">Contact Me</a> </p>
														</td>
														<td  width="20%"  height="80%" style=" text-align:center; ">
															<h2 style=" "><a href="add_page.php">
															<img class="user_comment_img" src="../assets/images/team/flower_img2.png" style="width:150px; height:150px;" />
															 
															<br>Sama'a AL-Zandani </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> Member </h4>
															<p> System anlysis </p>
															<p> Documentation  </p>
															<p> <a href="fb">Contact Me</a> </p>
														</td>
														
													</tr>
												</table>
													
									</td>
								</tr>
							</table>

