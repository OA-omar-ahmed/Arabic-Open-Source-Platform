 
								<table  width="100%"  height="100%" >
									<td  width="100%"  height="80%"  style="background:white; color:#333;overflow:auto; max-width:600px; ">
													
													
				
							<!-- Thumbnails  --> 			
												<table border="0" align="center" width="90%"  height="100%">
													<tr  >
													<td colspan="3" >
												 <center> <h2>About </h2></center>
													</td>
													</tr>
													<tr  >
														<td  width="30%"  height="80%" style=" text-align:center; ">
															<h2 style=" "><a href="../assets/images/oa_os_codes.jpg">
															<img class="user_comment_img" src="../assets/images/oa_os_codes.jpg" style="width:200px; height:200px;" />
															<br>عن   منصة   مشاريع والمصادر المفتوحة </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;"> المميزات</h4>
															<p> منصة لعمل ونشر للغة برمجية باللغة العربية</p>
															<p> منصة لمشاركة الطلاب  والمبرمجين مشاريعك </p>
															<p>   منصة ومكتبة تعليمية </p>
															<p> عرض  والتسويق لمشاريعك  واعمالك </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">شرح كيفية الاستخدام </a> | <a href="index.php">البدء</a> </p>
														</td>
														 <td  width="30%"  height="80%" style=" text-align:center; ">
															<h2 style=" "><a href="../assets/images/oa_os_codes.jpg">
															<img class="user_comment_img" src="../assets/images/oa_os_codes.jpg" style="width:200px; height:200px;" />
															<br>الاخبار   </a>  </h2>
															<h4 style=" background:rgb(0,168,217); color:white;">  الاخبار عن المنصة </h4>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">الموقع الرسمي</a> </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">فيسبوك</a> </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">تويتر </a> </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">لينكد ان </a> </p>
															<p> <a href="https://www.facebook.com/0marAhmedOfficial/">يوتيوب</a> </p>
															 
														</td>
														 
														
													</tr>
												</table>
													
									</td>
								</tr>
							</table>

