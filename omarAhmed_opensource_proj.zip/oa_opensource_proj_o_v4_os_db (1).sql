-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2023 at 10:04 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oa_opensource_proj_o_v4_os_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments_tb`
--

CREATE TABLE `comments_tb` (
  `id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `project_id` text NOT NULL,
  `user_id` text NOT NULL,
  `date` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments_tb`
--

INSERT INTO `comments_tb` (`id`, `comment`, `project_id`, `user_id`, `date`) VALUES
(2, 'very nice', '1', '1', '02/03/2022 17:45'),
(28, 'very nice', '2', '1', '02/03/2022 19:34'),
(47, 'nice', '9', '1', '01/04/2023 21:24');

-- --------------------------------------------------------

--
-- Table structure for table `projects_tb`
--

CREATE TABLE `projects_tb` (
  `id` int(11) NOT NULL,
  `logo_img` text NOT NULL,
  `proj_class` text NOT NULL,
  `user_id` text NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `published_date` text NOT NULL,
  `date_last_update` text NOT NULL,
  `proj_status` text NOT NULL,
  `version_num` text NOT NULL,
  `cat_id` text NOT NULL,
  `downloads_num` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects_tb`
--

INSERT INTO `projects_tb` (`id`, `logo_img`, `proj_class`, `user_id`, `name`, `description`, `published_date`, `date_last_update`, `proj_status`, `version_num`, `cat_id`, `downloads_num`) VALUES
(1, '6', 'PHP', '1', 'Open source project php (priv)', 'this is lesson of php this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C# this is lesson of C#', 'hidden', '', 'only_me', 'v1', 'hidden - open source', 'hidden - 1'),
(2, '9', 'Open Source - PHP', '3', 'Open source project php LMS', 'Learning management system', '22/01/2022 19:04', '-', 'only_me', '1', 'Open Source Programming Projects', '3'),
(9, '5', 'Open Source - PHP', '1', 'امثلة لاكواد html و css', 'امثلة لاكواد html و css: search filters , Contact Chips , Animated Seach Form , Alerts ... and others', '29/12/2022 20:07', '-', 'Public', '1.1', 'Lessons', '2'),
(3, '11', 'Open Source - PHP', '1', 'open source HTML & Text editor by omar ahmed', 'open source HTML & Text editor by omar ahmed.', '28/01/2022 19:56', '-', 'Private', '1', 'Open Source Programming Projects', '1'),
(4, '3', 'Open Source - PHP', '', 'omar test login', 'this is test', '27/12/2022 15:11', '-', 'Public', '1', 'Open Source Programming Projects', 'عدد التحميلات 0'),
(8, '1', 'Open Source - PHP', '1', 'html compiler', 'OA basick compiler', '27/12/2022 20:57', '-', 'Private', '1.1', 'Open Source Programming Projects', 'عدد التحميلات 0'),
(6, 'عدد المشاهدات 1', 'Open Source - PHP', '7', 'ooooooohtml css compiler by OA', 'html css compiler by Omar ahmed', '27/12/2022 19:28', '-', 'only_me', '1', 'Open Source Programming Projects', 'عدد التحميلات 0'),
(7, 'عدد المشاهدات 1', 'Open Source - PHP', '7', 'html css compiler by OA', 'html css compiler by Omar ahmed', '27/12/2022 19:28', '-', 'only_me', '1', 'Open Source Programming Projects', 'عدد التحميلات 0');

-- --------------------------------------------------------

--
-- Table structure for table `tb_uploaded_file`
--

CREATE TABLE `tb_uploaded_file` (
  `idfile` int(11) NOT NULL,
  `srcfi` text NOT NULL,
  `fkid` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_uploaded_file`
--

INSERT INTO `tb_uploaded_file` (`idfile`, `srcfi`, `fkid`) VALUES
(1, 'uploads/419bf9a23a21d0ae44364618517f0f82.png', '1'),
(2, 'uploads/aa24558276307fb84144533f2c0ee285.png', '1'),
(3, 'uploads/2253596e3adf79326676f963fef2403e.png', '1'),
(4, 'uploads/9650b20859176c81d19a70ccac79fbb4.png', 'imgN_users_tb_rec_record__1'),
(5, 'uploads/4ed697f1a454a06b1a5135acef36dbac.png', 'imgN_users_tb_rec_record__2'),
(6, 'uploads/f08fd9622f61540bcc905d6d42ebc2b8.png', 'imgN_projects_tb_rec_record__1'),
(8, 'uploads/d4dae29dc375f2d69c0cc6024c5e5aeb.zip', 'fiN4306735f8f7afd7f63d8c3bd14161ce9'),
(9, 'uploads/7df148bbf2c0f3b91aa5afc8ef1f3750.png', 'imgN_projects_tb_rec_record__2'),
(10, 'uploads/51bc551ea43a537a300e9ed0d2a11388.zip', 'fiN7bd3a145fcd546b99f88c63977282169'),
(11, 'uploads/fb92dbe3e0cbfa992bb09d41148ea520.png', 'imgN_projects_tb_rec_record__3'),
(12, 'uploads/03468ed8834095e564fce43393e77d14.zip', 'fiN402ebbf409c9d05bf158124979173e24'),
(13, 'uploads/ee028526830d4c644d2056545f4d294d.png', ''),
(14, 'uploads/108c81dc2e7aee5a2a5564ee9a201c98.png', 'imgN_users_tb_rec_record__3'),
(15, 'uploads/71f759121b6adb4423357358b6e741e7.zip', 'fiN4bc6353a886f513228863f4956f77277'),
(16, 'uploads/2153d00095827c2c05f43070540955da.png', 'imgN_projects_tb_rec_record__9'),
(17, 'uploads/24159dbba4ed57663aa6a62aa8087930.png', 'imgN_projects_tb_rec_record__9'),
(18, 'uploads/4c882c8b8f1019f7db30007e0cdabc9a.png', 'imgN_projects_tb_rec_record__9'),
(19, 'uploads/6cc0409b26a5d0c31ef30d9e0ed2025a.png', 'imgN_projects_tb_rec_record__9'),
(20, 'uploads/0687401e5c54da3ad11bf066af38f1dc.png', 'imgN_projects_tb_rec_record__9'),
(21, 'uploads/3b1f1e1f8c93e0372f0f27c90e1db392.png', 'imgN_projects_tb_rec_record__9');

-- --------------------------------------------------------

--
-- Table structure for table `users_tb`
--

CREATE TABLE `users_tb` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `user_password` text NOT NULL,
  `user_name` text NOT NULL,
  `type_user` text NOT NULL,
  `description_profile` text NOT NULL,
  `account_setting` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_tb`
--

INSERT INTO `users_tb` (`id`, `name`, `email`, `user_password`, `user_name`, `type_user`, `description_profile`, `account_setting`) VALUES
(1, 'Omar Ahmed', 'omar@gmail.com', 'd4466cce49457cfea18222f5a7cd3573', 'omar', 'Developer-Programmar', 'this is omar is developer and not a user-company-team', '1'),
(2, 'Omar Ahmed', 'omarahmed.edu@gmail.com', 'd4466cce49457cfea18222f5a7cd3573', 'omar_ahmed', 'Developer-Programmar', 'this is omar is developer and not a user-company-team', 'العامة'),
(3, 'Doaa Asaf', 'doaa@gmail.com', 'dd322ca0a2102254ac7ccc5a2e7c04f4', 'doaa', '1', 'i am programmer', 'العامة'),
(4, 'سماء الزنداني', 'samaa@gmail.com', '04ea44663cfebbfd64f1a440791334e0', 'samaa', '1', 'i am programmer', '1'),
(5, 'omar2', 'omar2@gmail.com', 'd4466cce49457cfea18222f5a7cd3573', 'omar2', 'cybersecurity', 'this is test of cybersecurity', 'العامة'),
(7, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', '1', 'admin', '1'),
(9, 'hadi', 'hadi', 'd4466cce49457cfea18222f5a7cd3573', 'hadi@gmail.com', '', 'hadi@gmail.com', 'العامة'),
(10, 'hamod', 'hamod@gmail.com', 'd4466cce49457cfea18222f5a7cd3573', 'hamod@gmail.com', '', 'hamod@gmail.com', 'العامة'),
(11, 'user', 'user@gmail.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', '', 'user@gmail.com test', 'العامة');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments_tb`
--
ALTER TABLE `comments_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects_tb`
--
ALTER TABLE `projects_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_uploaded_file`
--
ALTER TABLE `tb_uploaded_file`
  ADD PRIMARY KEY (`idfile`);

--
-- Indexes for table `users_tb`
--
ALTER TABLE `users_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments_tb`
--
ALTER TABLE `comments_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `projects_tb`
--
ALTER TABLE `projects_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tb_uploaded_file`
--
ALTER TABLE `tb_uploaded_file`
  MODIFY `idfile` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users_tb`
--
ALTER TABLE `users_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
