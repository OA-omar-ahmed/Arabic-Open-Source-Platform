<?php
// /*
// Database Configuration  Constants
defined('DB_SERVER') ? null : define("DB_SERVER", "localhost");
defined('DB_NAME')   ? null : define("DB_NAME", "oa_opensource_proj_o_v4_os_db");
defined('DB_USER')   ? null : define("DB_USER", "root");
defined('DB_PASS')   ? null : define("DB_PASS", "");
// // */
?>