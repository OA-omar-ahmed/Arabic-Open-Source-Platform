<?php
     include_once "config.php";
?><?php /***************************************************************************
*_==================================_IMPORTANT_:_==================================__
	**_This_is_an_educational_product_made_by_OmarAhmed_and_his_team._and_cannot_be_modified_for_other_than_personal_usage.
	**_This_product_cannot_be_redistributed_for_free_or_a_fee_without_written_permission_from_OmarAhmed.
	**_This_notice_may_not_be_removed_from_the_source_code.
****************************************************************************/ ?>
 